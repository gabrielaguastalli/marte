package br.com.fiap.marte.paineis;

import java.awt.GridLayout;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class PainelCampos extends JPanel {


	private static final long serialVersionUID = 1L;
	
	private JTextField dataTerra = new JTextField();
	private JFormattedTextField horaTerra = new JFormattedTextField();
	private JTextField diasMarte = new JTextField();
	private JTextField longSolar = new JTextField();
	private JTextField densidadeAtm = new JTextField();
	private JTextField tempMax = new JTextField();
	private JTextField tempMin = new JTextField();
	//private PainelTemperatura temperatura = new PainelTemperatura();
	private JTextField pressaoAtm = new JTextField();
	
	public PainelCampos() {
		setLayout(new GridLayout(8,1));
		setBorder(new EmptyBorder(20,10,20,10));
		init();
		}
	
	private void init() {
		add(new JLabel("Data na Terra"));
		add(getDataTerra());
		add(new JLabel("Hora na Terra"));
		add(getHoraTerra());
		add(new JLabel("Dias em Marte"));
		add(getDiasMarte());
		add(new JLabel("LongitudeSolar"));
		add(getLongSolar());
		add(new JLabel("Densidade Atmosf�rica"));
		add(getDensidadeAtm());
		add(new JLabel("Temperatura M�xima do dia"));
		add(getTempMax());
		add(new JLabel("Temperatura M�nima do dia"));
		add(getTempMin());
		add(new JLabel("Press�o Atmosf�rica"));
		add(getPressaoAtm());
	}

	public JTextField getPressaoAtm() {
		return pressaoAtm;
	}

	
	public JTextField getTempMin() {
		return tempMin;
	}

	
	public JTextField getTempMax() {
		return tempMax;
	}

	
	public JTextField getDensidadeAtm() {
		return densidadeAtm;
	}

	public JTextField getLongSolar() {
		return longSolar;
	}

	public JTextField getDiasMarte() {
		return diasMarte;
	}

	public JTextField getDataTerra() {
		return dataTerra;
	}

	public JTextField getHoraTerra() {
		return horaTerra;
	}
}
