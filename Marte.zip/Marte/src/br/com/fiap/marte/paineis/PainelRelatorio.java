package br.com.fiap.marte.paineis;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PainelRelatorio extends JPanel{

	private static final long serialVersionUID = 1L;

	private JLabel relatorio = new JLabel("Relat�rios Diarios");
	
	public PainelRelatorio() {
		init();
	}

	private void init() {
		add(relatorio);
		
	}
}