package br.com.fiap.marte.listener;
 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import br.com.fiap.marte.dao.Dao;
import br.com.fiap.marte.model.Missao; 
import br.com.fiap.marte.paineis.PainelCadastro;
 
 public class BotaoListener implements ActionListener {
 
	 private PainelCadastro painelCadastro;
 
	 private Dao dao = new Dao();
 
 	public BotaoListener(PainelCadastro painelCadastro) {
 		this.painelCadastro = painelCadastro; }
 
 	@Override 
 	public void actionPerformed(ActionEvent e) {
 
	 //if(e.getSource() == salvar) { salvarMissao(); }
 
	 //if(e.getSource() == cancelar) { cancelar(); }
 
	 
	 		 Missao missao = new Missao();
	 		 missao.setDataTerra(painelCadastro.getCampos().getDataTerra().getText());
			 missao.setHoraTerra(painelCadastro.getCampos().getHoraTerra().getText());
			 missao.setDiasMarte(painelCadastro.getCampos().getDiasMarte().getText());
			 missao.setLongSolar(painelCadastro.getCampos().getLongSolar().getText());
			 missao.setDensidadeAtm(painelCadastro.getCampos().getDensidadeAtm().getText());
			 missao.setTempMax(painelCadastro.getCampos().getTempMax().getText());
			 missao.setTempMin(painelCadastro.getCampos().getTempMin().getText());
			 missao.setPressaoAtm(painelCadastro.getCampos().getPressaoAtm().getText());
	 
		 System.out.println(missao);
 
		 dao.create(missao);
 	}
 		private void cancelar() { JOptionPane.showMessageDialog(painelCadastro, this, "Cancelado", 0); }
 		private void salvarMissao() {
 	
 
 		}
 } 		
 		
 		
 

 