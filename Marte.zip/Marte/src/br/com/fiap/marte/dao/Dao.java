package br.com.fiap.marte.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import br.com.fiap.marte.model.Missao;

public class Dao {

	public void create(Missao missao) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("marte");
		EntityManager manager = factory.createEntityManager();
		
		
		manager.getTransaction().begin();
		manager.persist(missao);
		manager.getTransaction().commit();
		
		manager.close();
	}
	
	public List<Missao> consulta() {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("marte");
		EntityManager manager = factory.createEntityManager();
		
		TypedQuery<Missao> query = manager.createQuery("SELECT m FROM Missao m", Missao.class);
		return query.getResultList();
		
	}

}
