package br.com.fiap.marte.model;

import java.util.Calendar;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Missao {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String dataTerra;
	private Calendar horaTerra;
	private int diasMarte;
	private float longSolar;
	private float densidadeAtm;
	private float tempMax;
	private float tempMin;
	private float pressaoAtm;
	
	public Missao() {
		
	}
	
	@Override
	public String toString() {
		return "Missao [dataTerra=" + dataTerra + 
				", horaTerra=" + horaTerra + 
				", diasMarte=" + diasMarte +
				", longSolar=" + longSolar + 
				", densidadeAtm=" + densidadeAtm +
				", tempMax=" + tempMax +
				", tempMin=" + tempMin + 
				", pressaoAtm=" + pressaoAtm + "]";
	}

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}



	public void setDataTerra(String dataTerra) {
		this.dataTerra = dataTerra;
	}



	public void setHoraTerra(String text) {
		
		
	}



	public void setDiasMarte(String text) {
	
		
	}



	public void setLongSolar(String text) {
		
		
	}



	public void setDensidadeAtm(String text) {
		
		
	}



	public void setTempMax(String text) {
		
	}



	public void setTempMin(String text) {
		
		
	}



	public void setPressaoAtm(String text) {

		
	}
	
	public String getDataTerra() {
		return dataTerra;
	}



	public Calendar getHoraTerra() {
		return horaTerra;
	}



	public int getDiasMarte() {
		return diasMarte;
	}



	public float getLongSolar() {
		return longSolar;
	}



	public float getDensidadeAtm() {
		return densidadeAtm;
	}



	public float getTempMax() {
		return tempMax;
	}



	public float getTempMin() {
		return tempMin;
	}



	public float getPressaoAtm() {
		return pressaoAtm;
	}


	
	
	
}
